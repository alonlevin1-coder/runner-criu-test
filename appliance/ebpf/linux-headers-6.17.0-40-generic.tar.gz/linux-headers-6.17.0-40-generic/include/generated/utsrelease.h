#define UTS_RELEASE "6.17.0-40-generic"
#define UTS_UBUNTU_RELEASE_ABI 40
