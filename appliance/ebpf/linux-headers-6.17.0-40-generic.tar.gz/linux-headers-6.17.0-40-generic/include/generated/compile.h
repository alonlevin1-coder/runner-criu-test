#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"buildd"
#define LINUX_COMPILE_HOST	"lcy02-amd64-067"
#define LINUX_COMPILER		"x86_64-linux-gnu-gcc-13 (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, GNU ld (GNU Binutils for Ubuntu) 2.42"
