	.file	"asm-offsets.c"
# GNU C11 (Ubuntu 13.3.0-6ubuntu2~24.04.1) version 13.3.0 (x86_64-linux-gnu)
#	compiled by GNU C version 13.3.0, GMP version 6.3.0, MPFR version 4.2.1, MPC version 1.3.1, isl version isl-0.26-GMP

# GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
# options passed: -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -mno-sse4a -m64 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -march=x86-64 -mtune=generic -mno-red-zone -mcmodel=kernel -mstack-protector-guard-reg=gs -mstack-protector-guard-symbol=__ref_stack_chk_guard -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -mharden-sls=all -mrecord-mcount -mfentry -O2 -std=gnu11 -p -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -fcf-protection=none -falign-jumps=1 -falign-loops=1 -fno-asynchronous-unwind-tables -fno-jump-tables -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -fno-allow-store-data-races -fstack-protector-strong -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -fno-stack-clash-protection -fzero-call-used-regs=used-gpr -fno-inline-functions-called-once -falign-functions=16 -fstrict-flex-arrays=3 -fno-strict-overflow -fstack-check=no -fconserve-stack -fno-builtin-wcslen -fstack-protector-strong
	.text
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.section	__patchable_function_entries,"awo",@progbits,.LPFE5067
	.align 8
	.quad	.LPFE5067
	.section	.text.startup
.LPFE5067:
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	.type	main, @function
main:
1:	call	__fentry__
	.section __mcount_loc, "a",@progbits
	.quad 1b
	.previous
	pushq	%rbp	#
	movq	%rsp, %rbp	#,
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:20: 	BLANK();
#APP
# 20 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:24: 	OFFSET(KVM_STEAL_TIME_preempted, kvm_steal_time, preempted);
# 24 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->KVM_STEAL_TIME_preempted $16 offsetof(struct kvm_steal_time, preempted)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:25: 	BLANK();
# 25 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:29: 	ENTRY(bx);
# 29 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_bx $40 offsetof(struct pt_regs, bx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:30: 	ENTRY(cx);
# 30 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_cx $88 offsetof(struct pt_regs, cx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:31: 	ENTRY(dx);
# 31 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_dx $96 offsetof(struct pt_regs, dx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:32: 	ENTRY(sp);
# 32 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_sp $152 offsetof(struct pt_regs, sp)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:33: 	ENTRY(bp);
# 33 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_bp $32 offsetof(struct pt_regs, bp)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:34: 	ENTRY(si);
# 34 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_si $104 offsetof(struct pt_regs, si)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:35: 	ENTRY(di);
# 35 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_di $112 offsetof(struct pt_regs, di)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:36: 	ENTRY(r8);
# 36 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r8 $72 offsetof(struct pt_regs, r8)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:37: 	ENTRY(r9);
# 37 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r9 $64 offsetof(struct pt_regs, r9)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:38: 	ENTRY(r10);
# 38 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r10 $56 offsetof(struct pt_regs, r10)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:39: 	ENTRY(r11);
# 39 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r11 $48 offsetof(struct pt_regs, r11)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:40: 	ENTRY(r12);
# 40 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r12 $24 offsetof(struct pt_regs, r12)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:41: 	ENTRY(r13);
# 41 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r13 $16 offsetof(struct pt_regs, r13)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:42: 	ENTRY(r14);
# 42 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r14 $8 offsetof(struct pt_regs, r14)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:43: 	ENTRY(r15);
# 43 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_r15 $0 offsetof(struct pt_regs, r15)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:44: 	ENTRY(flags);
# 44 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->pt_regs_flags $144 offsetof(struct pt_regs, flags)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:45: 	BLANK();
# 45 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:49: 	ENTRY(cr0);
# 49 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->saved_context_cr0 $200 offsetof(struct saved_context, cr0)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:50: 	ENTRY(cr2);
# 50 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->saved_context_cr2 $208 offsetof(struct saved_context, cr2)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:51: 	ENTRY(cr3);
# 51 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->saved_context_cr3 $216 offsetof(struct saved_context, cr3)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:52: 	ENTRY(cr4);
# 52 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->saved_context_cr4 $224 offsetof(struct saved_context, cr4)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:53: 	ENTRY(gdt_desc);
# 53 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->saved_context_gdt_desc $266 offsetof(struct saved_context, gdt_desc)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:54: 	BLANK();
# 54 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets_64.c:58: }
#NO_APP
	xorl	%eax, %eax	#
	popq	%rbp	#
	jmp	__x86_return_thunk
	.size	main, .-main
	.text
	.p2align 4
	.section	__patchable_function_entries,"awo",@progbits,.LPFE5068
	.align 8
	.quad	.LPFE5068
	.text
.LPFE5068:
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	.type	common, @function
common:
1:	call	__fentry__
	.section __mcount_loc, "a",@progbits
	.quad 1b
	.previous
	pushq	%rbp	#
	movq	%rsp, %rbp	#,
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:36: 	OFFSET(CPUINFO_x86, cpuinfo_x86, x86);
#APP
# 36 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPUINFO_x86 $1 offsetof(struct cpuinfo_x86, x86)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:37: 	OFFSET(CPUINFO_x86_vendor, cpuinfo_x86, x86_vendor);
# 37 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPUINFO_x86_vendor $2 offsetof(struct cpuinfo_x86, x86_vendor)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:38: 	OFFSET(CPUINFO_x86_model, cpuinfo_x86, x86_model);
# 38 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPUINFO_x86_model $0 offsetof(struct cpuinfo_x86, x86_model)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:39: 	OFFSET(CPUINFO_x86_stepping, cpuinfo_x86, x86_stepping);
# 39 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPUINFO_x86_stepping $4 offsetof(struct cpuinfo_x86, x86_stepping)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:40: 	OFFSET(CPUINFO_cpuid_level, cpuinfo_x86, cpuid_level);
# 40 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPUINFO_cpuid_level $40 offsetof(struct cpuinfo_x86, cpuid_level)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:41: 	OFFSET(CPUINFO_x86_capability, cpuinfo_x86, x86_capability);
# 41 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPUINFO_x86_capability $48 offsetof(struct cpuinfo_x86, x86_capability)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:42: 	OFFSET(CPUINFO_x86_vendor_id, cpuinfo_x86, x86_vendor_id);
# 42 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPUINFO_x86_vendor_id $144 offsetof(struct cpuinfo_x86, x86_vendor_id)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:44: 	BLANK();
# 44 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:45: 	OFFSET(TASK_threadsp, task_struct, thread.sp);
# 45 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TASK_threadsp $9560 offsetof(struct task_struct, thread.sp)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:47: 	OFFSET(TASK_stack_canary, task_struct, stack_canary);
# 47 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TASK_stack_canary $2712 offsetof(struct task_struct, stack_canary)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:50: 	BLANK();
# 50 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:51: 	OFFSET(pbe_address, pbe, address);
# 51 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->pbe_address $0 offsetof(struct pbe, address)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:52: 	OFFSET(pbe_orig_address, pbe, orig_address);
# 52 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->pbe_orig_address $8 offsetof(struct pbe, orig_address)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:53: 	OFFSET(pbe_next, pbe, next);
# 53 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->pbe_next $16 offsetof(struct pbe, next)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:56: 	BLANK();
# 56 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:57: 	OFFSET(IA32_SIGCONTEXT_ax, sigcontext_32, ax);
# 57 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_ax $44 offsetof(struct sigcontext_32, ax)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:58: 	OFFSET(IA32_SIGCONTEXT_bx, sigcontext_32, bx);
# 58 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_bx $32 offsetof(struct sigcontext_32, bx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:59: 	OFFSET(IA32_SIGCONTEXT_cx, sigcontext_32, cx);
# 59 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_cx $40 offsetof(struct sigcontext_32, cx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:60: 	OFFSET(IA32_SIGCONTEXT_dx, sigcontext_32, dx);
# 60 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_dx $36 offsetof(struct sigcontext_32, dx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:61: 	OFFSET(IA32_SIGCONTEXT_si, sigcontext_32, si);
# 61 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_si $20 offsetof(struct sigcontext_32, si)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:62: 	OFFSET(IA32_SIGCONTEXT_di, sigcontext_32, di);
# 62 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_di $16 offsetof(struct sigcontext_32, di)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:63: 	OFFSET(IA32_SIGCONTEXT_bp, sigcontext_32, bp);
# 63 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_bp $24 offsetof(struct sigcontext_32, bp)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:64: 	OFFSET(IA32_SIGCONTEXT_sp, sigcontext_32, sp);
# 64 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_sp $28 offsetof(struct sigcontext_32, sp)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:65: 	OFFSET(IA32_SIGCONTEXT_ip, sigcontext_32, ip);
# 65 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_SIGCONTEXT_ip $56 offsetof(struct sigcontext_32, ip)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:67: 	BLANK();
# 67 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:68: 	OFFSET(IA32_RT_SIGFRAME_sigcontext, rt_sigframe_ia32, uc.uc_mcontext);
# 68 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->IA32_RT_SIGFRAME_sigcontext $164 offsetof(struct rt_sigframe_ia32, uc.uc_mcontext)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:72: 	BLANK();
# 72 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:73: 	OFFSET(XEN_vcpu_info_mask, vcpu_info, evtchn_upcall_mask);
# 73 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->XEN_vcpu_info_mask $1 offsetof(struct vcpu_info, evtchn_upcall_mask)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:74: 	OFFSET(XEN_vcpu_info_pending, vcpu_info, evtchn_upcall_pending);
# 74 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->XEN_vcpu_info_pending $0 offsetof(struct vcpu_info, evtchn_upcall_pending)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:75: 	OFFSET(XEN_vcpu_info_arch_cr2, vcpu_info, arch.cr2);
# 75 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->XEN_vcpu_info_arch_cr2 $16 offsetof(struct vcpu_info, arch.cr2)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:78: 	BLANK();
# 78 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:79: 	OFFSET(TDX_MODULE_rcx, tdx_module_args, rcx);
# 79 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_rcx $0 offsetof(struct tdx_module_args, rcx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:80: 	OFFSET(TDX_MODULE_rdx, tdx_module_args, rdx);
# 80 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_rdx $8 offsetof(struct tdx_module_args, rdx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:81: 	OFFSET(TDX_MODULE_r8,  tdx_module_args, r8);
# 81 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r8 $16 offsetof(struct tdx_module_args, r8)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:82: 	OFFSET(TDX_MODULE_r9,  tdx_module_args, r9);
# 82 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r9 $24 offsetof(struct tdx_module_args, r9)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:83: 	OFFSET(TDX_MODULE_r10, tdx_module_args, r10);
# 83 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r10 $32 offsetof(struct tdx_module_args, r10)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:84: 	OFFSET(TDX_MODULE_r11, tdx_module_args, r11);
# 84 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r11 $40 offsetof(struct tdx_module_args, r11)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:85: 	OFFSET(TDX_MODULE_r12, tdx_module_args, r12);
# 85 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r12 $48 offsetof(struct tdx_module_args, r12)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:86: 	OFFSET(TDX_MODULE_r13, tdx_module_args, r13);
# 86 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r13 $56 offsetof(struct tdx_module_args, r13)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:87: 	OFFSET(TDX_MODULE_r14, tdx_module_args, r14);
# 87 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r14 $64 offsetof(struct tdx_module_args, r14)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:88: 	OFFSET(TDX_MODULE_r15, tdx_module_args, r15);
# 88 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_r15 $72 offsetof(struct tdx_module_args, r15)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:89: 	OFFSET(TDX_MODULE_rbx, tdx_module_args, rbx);
# 89 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_rbx $80 offsetof(struct tdx_module_args, rbx)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:90: 	OFFSET(TDX_MODULE_rdi, tdx_module_args, rdi);
# 90 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_rdi $88 offsetof(struct tdx_module_args, rdi)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:91: 	OFFSET(TDX_MODULE_rsi, tdx_module_args, rsi);
# 91 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TDX_MODULE_rsi $96 offsetof(struct tdx_module_args, rsi)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:93: 	BLANK();
# 93 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:94: 	OFFSET(BP_scratch, boot_params, scratch);
# 94 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_scratch $484 offsetof(struct boot_params, scratch)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:95: 	OFFSET(BP_secure_boot, boot_params, secure_boot);
# 95 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_secure_boot $492 offsetof(struct boot_params, secure_boot)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:96: 	OFFSET(BP_loadflags, boot_params, hdr.loadflags);
# 96 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_loadflags $529 offsetof(struct boot_params, hdr.loadflags)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:97: 	OFFSET(BP_hardware_subarch, boot_params, hdr.hardware_subarch);
# 97 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_hardware_subarch $572 offsetof(struct boot_params, hdr.hardware_subarch)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:98: 	OFFSET(BP_version, boot_params, hdr.version);
# 98 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_version $518 offsetof(struct boot_params, hdr.version)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:99: 	OFFSET(BP_kernel_alignment, boot_params, hdr.kernel_alignment);
# 99 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_kernel_alignment $560 offsetof(struct boot_params, hdr.kernel_alignment)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:100: 	OFFSET(BP_init_size, boot_params, hdr.init_size);
# 100 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_init_size $608 offsetof(struct boot_params, hdr.init_size)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:101: 	OFFSET(BP_pref_address, boot_params, hdr.pref_address);
# 101 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->BP_pref_address $600 offsetof(struct boot_params, hdr.pref_address)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:103: 	BLANK();
# 103 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:104: 	DEFINE(PTREGS_SIZE, sizeof(struct pt_regs));
# 104 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->PTREGS_SIZE $168 sizeof(struct pt_regs)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:107: 	OFFSET(TLB_STATE_user_pcid_flush_mask, tlb_state, user_pcid_flush_mask);
# 107 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TLB_STATE_user_pcid_flush_mask $22 offsetof(struct tlb_state, user_pcid_flush_mask)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:110: 	OFFSET(CPU_ENTRY_AREA_entry_stack, cpu_entry_area, entry_stack_page);
# 110 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->CPU_ENTRY_AREA_entry_stack $4096 offsetof(struct cpu_entry_area, entry_stack_page)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:111: 	DEFINE(SIZEOF_entry_stack, sizeof(struct entry_stack));
# 111 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->SIZEOF_entry_stack $4096 sizeof(struct entry_stack)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:112: 	DEFINE(MASK_entry_stack, (~(sizeof(struct entry_stack) - 1)));
# 112 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->MASK_entry_stack $-4096 (~(sizeof(struct entry_stack) - 1))"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:115: 	OFFSET(TSS_sp0, tss_struct, x86_tss.sp0);
# 115 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TSS_sp0 $4 offsetof(struct tss_struct, x86_tss.sp0)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:116: 	OFFSET(TSS_sp1, tss_struct, x86_tss.sp1);
# 116 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TSS_sp1 $12 offsetof(struct tss_struct, x86_tss.sp1)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:117: 	OFFSET(TSS_sp2, tss_struct, x86_tss.sp2);
# 117 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->TSS_sp2 $20 offsetof(struct tss_struct, x86_tss.sp2)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:120: 	BLANK();
# 120 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->"
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:121: 	OFFSET(ARIA_CTX_enc_key, aria_ctx, enc_key);
# 121 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->ARIA_CTX_enc_key $0 offsetof(struct aria_ctx, enc_key)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:122: 	OFFSET(ARIA_CTX_dec_key, aria_ctx, dec_key);
# 122 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->ARIA_CTX_dec_key $272 offsetof(struct aria_ctx, dec_key)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:123: 	OFFSET(ARIA_CTX_rounds, aria_ctx, rounds);
# 123 "/build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c" 1
	
.ascii "->ARIA_CTX_rounds $544 offsetof(struct aria_ctx, rounds)"	#
# 0 "" 2
# /build/linux-hwe-6.17-oHJpUZ/linux-hwe-6.17-6.17.0/arch/x86/kernel/asm-offsets.c:126: }
#NO_APP
	popq	%rbp	#
	jmp	__x86_return_thunk
	.size	common, .-common
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
